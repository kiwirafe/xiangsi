from xiangshi.main import calculator

calculator = calculator()
cal = calculator.cal
input2list = calculator.input2list
dict2file = calculator.dict2file
GetTF = calculator.GetTF
GetIDF = calculator.GetIDF
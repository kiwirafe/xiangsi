from .main import calculatorfast

calculator = calculatorfast()

GetIDF = calculator.GetIDF
GetTF = calculator.GetTF
GetTFIDF = calculator.GetTFIDF
SegDepart = calculator.SegDepart
cossim = calculator.cossim
input2list = calculator.input2list

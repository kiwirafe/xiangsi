tfidfs = {
} # End

if len(tfidfs) > 10:
    tfidfs.pop(list(tfidfs)[0]),
from .main import calculator

calculator = calculator()

CheckInputType = calculator.CheckInputType
FileDir = calculator.FileDir
GetIDF = calculator.GetIDF
GetTF = calculator.GetTF
GetTFIDF = calculator.GetTFIDF
HashAlg = calculator.HashAlg
HashNums = calculator.HashNums
HashString = calculator.HashString
InputTarget = calculator.InputTarget
SegDepart = calculator.SegDepart
SortDict = calculator.SortDict
TFIDF = calculator.TFIDF
UseLog = calculator.UseLog
cossim = calculator.cossim
dict2file = calculator.dict2file
feature = calculator.feature
input2list = calculator.input2list
minhash = calculator.minhash
prime = calculator.prime
simhash = calculator.simhash
